# Databricks notebook source
spark.conf.set('fs.azure.account.key.formula1dlgerardo.dfs.core.windows.net', 'yr/ETWANeADWjggSQAb3rm0pXAC6W7APyLpnn6M6Ykal4PLwu+ScoVR3pLTr92dR2H4N4DMAKKVS+AStW1w43Q==')

# COMMAND ----------

display(dbutils.fs.ls('abfss://demo@formula1dlgerardo.dfs.core.windows.net'))

# COMMAND ----------

dbutils.secrets.listScopes()


# COMMAND ----------

dbutils.secrets.list(scope='formula1-scope')

# COMMAND ----------

dbutils.secrets.get(scope='formula1-scope',key = 'formula1dl-account-key')

# COMMAND ----------

formula1dl-account-key = dbutils.secrets.get(scope='formula1-scope',key = 'formula1dl-account-key')


# COMMAND ----------

spark.conf.set('fs.azure.account.key.formula1dlgerardo.dfs.core.windows.net', formula1dl-account-key)

# COMMAND ----------

