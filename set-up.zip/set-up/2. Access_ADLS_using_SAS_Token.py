# Databricks notebook source
spark.conf.set("fs.azure.account.auth.type.formula1dlgerardo.dfs.core.windows.net", "SAS")
spark.conf.set("fs.azure.sas.token.provider.type.formula1dlgerardo.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
spark.conf.set("fs.azure.sas.fixed.token.formula1dlgerardo.dfs.core.windows.net", dbutils.secrets.get(scope="formula1-scope", key="formula1dl-sas-access"))

# COMMAND ----------

display(spark.read.csv('abfss://demo@formula1dlgerardo.dfs.core.windows.net/circuits.csv'))